clear;
clc;

axes('Position',[0.35 0.65 0.21 0.25]);
%TLL->TLL(SS>TS)
data1 = [0.01,-0.982;0.05,-0.925;0.20,-0.80;0.50,-0.70;0.65,-0.75;0.80,-0.81;0.90,-0.807;1.00,-0.763];
plot(data1(:,1),data1(:,2),'b--o','LineWidth',1,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on


%TLL(SS>TS)->LEL(SS)
data2 = [0.01,-0.982;0.05,-0.975;0.20,-0.975;0.50,-1.1;0.55,-1.3;0.58,-1.475];
plot(data2(:,1),data2(:,2),'b-o','LineWidth',1,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on

errorbary = [0.00;0.00;0.025;0.025;0.05;0.025];
errorbar(data2(:,1), data2(:,2), errorbary(:),errorbary(:),'vertical','b.','LineWidth',1.0','MarkerSize',1,'MarkerFaceColor','b','HandleVisibility','off')
hold on

plot([0.855,0.841,0.826,0.811,0.8045,0.798,0.779,0.7738,0.774,0.783],[-0.81,-0.912,-1.041,-1.107,-1.16,-1.194,-1.374,-1.425,-1.443,-1.59], 'b--','LineWidth',1.0)
hold on

%LEL(SS)->PS
data3 = [0.01,-1.00;0.05,-1.05;0.20,-1.25;0.50,-1.45;0.65,-1.55;0.80,-1.60;1.00,-1.625];
plot(data3(:,1),data3(:,2),'b-o','LineWidth',1,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on

plot([1.0,0.96,0.93,0.88,0.843,0.842],[-0.763,-1.2,-1.34,-1.46,-1.6,-1.605], 'b--','LineWidth',1.0)
hold on


set(gca,'XLim',[0.01 1]);
set(gca,'YLim',[-1.8, 0]);

set(gca,'xtick',0.0 : 0.2 : 1.0, 'FontSize',17,'LineWidth',1);
set(gca,'ytick',-2.0 : 0.4 : 0.0,'FontSize',17,'LineWidth',1);
set(gca,'xTickLabel', num2str(get(gca,'xtick')', '%.1f'));
set(gca, 'yTickLabel', num2str(get(gca,'ytick')', '%.1f'));
set(gca,'xminortick','off','TickLength',[0.02 0])  ;
set(gca,'yminortick','off','TickLength',[0.02 0])  ;



text(0.075, -0.25, '$U=2$','FontSize',18,'Interpreter','LaTex');

% text(-0.1715, 0, '($\rm{a}$)','FontSize',18.5,'Interpreter','LaTex');

text(0.5, -0.35, 'TLL','FontSize',15,'FontWeight','bold');
text(0.375, -0.925, 'TLL(SS>TS)','FontSize',15,'FontWeight','bold');
text(0.81, -1.55, 'TLL(SS≈TS)','FontSize',14,'FontWeight','bold','rotation',65);
text(0.7, -1.7, 'TLL(SS<TS)','FontSize',14,'FontWeight','bold');
text(0.25, -1.2, 'LEL(SS)','FontSize',15,'FontWeight','bold');
text(0.22, -1.575, 'PS','FontSize',15,'FontWeight','bold');

xlabel('$t^\prime$','FontSize',23,'Interpreter','LaTex');
text(-0.14,-0.925,'$V$','FontSize',18,'Interpreter','LaTex','rotation',90);
set(gcf,'color','w')


