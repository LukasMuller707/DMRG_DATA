clear;
clc;

axes('Position',[0.35 0.65 0.21 0.25]);
% TLL->TLL(SS>TS)
data1 = [0.01,-1.307;0.05,-1.226; 0.20,-1.08; 0.35,-1.044; 0.50,-1.089; 0.65,-1.227; 0.80,-1.44;0.90,-1.5754;0.95,-1.6204;1.0,-1.61];%0.7022,-1.301;
plot(data1(:,1),data1(:,2),'b--o','LineWidth',0.8,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on

plot([0.95,0.9345,0.9275,0.928],[-1.6204,-1.71,-1.796,-1.83], 'b--','LineWidth',1.0)
hold on

%TLL(SS>TS)->LEL(SS)
data2 = [0.01,-1.307;0.05,-1.275; 0.20,-1.225; 0.35,-1.225; 0.50,-1.325; 0.65,-1.625; 0.70,-1.68; 0.80,-1.8];
plot(data2(:,1),data2(:,2),'b-o','LineWidth',0.8,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on

x0bar=[0.0;0.0;0.025;0.025;0.025;0.0250;0.02;0];
x1bar=[0.0;0.0;0.025;0.025;0.025;0.0250;0.02;0];
errorbar(data2(:,1),data2(:,2),x0bar,x1bar,'vertical','k','LineWidth',0.7','MarkerSize',4,'MarkerFaceColor','k')
hold on

fill([0.99,1.00,1.0],[-1.8475,-1.85,-1.61],[203,139,203]/255,'EdgeColor','w','FaceAlpha', 0.5)
hold on

%LEL(SS)->PS
data3 = [0.01,-1.320;0.05,-1.325;0.20,-1.40;0.35,-1.50;0.50,-1.60;0.65,-1.70;0.80,-1.80;1.0,-1.85];
plot(data3(:,1),data3(:,2),'b-o','LineWidth',0.8,'MarkerSize',4,'MarkerFaceColor','[0.8078, 0.7451, 0.7451]')
hold on




set(gca,'XLim',[0.01 1]);
set(gca,'YLim',[-2, 0]);

set(gca,'xtick',0.0 : 0.2 : 1.0, 'FontSize',17, 'LineWidth', 1);
set(gca,'ytick',-2.0 : 0.4 : 0.0, 'FontSize',17,'LineWidth', 1);
set(gca, 'xTickLabel', num2str(get(gca,'xtick')', '%.1f'));
set(gca, 'yTickLabel', num2str(get(gca,'ytick')', '%.1f'));

text(0.075, -0.25, '$U=4$','FontSize',18,'Interpreter','LaTex');

% text(-0.175, 0, '($\rm{b}$)','FontSize',18,'Interpreter','LaTex');

text(-0.04, -2.175, '0.01','FontSize',17);

text(0.5, -0.45, 'TLL','FontSize',15,'FontWeight','bold');
text(0.225, -1.13, 'TLL(SS>TS)','FontSize',14,'FontWeight','bold','rotation',-2);
text(0.725, -1.3, 'TLL(SS≈TS)','FontSize',13,'FontWeight','bold','rotation',-8);
text(0.675, -1.9, 'TLL(SS<TS)','FontSize',14,'FontWeight','bold');
text(0.3, -1.375, 'LEL(SS)','FontSize',15,'FontWeight','bold','rotation',-5);
text(0.22, -1.75, 'PS','FontSize',15,'FontWeight','bold');

text(0.485,-2.375,'$t^\prime$','FontSize',20,'Interpreter','LaTex');
text(-0.14,-1.05,'$V$','FontSize',18,'Interpreter','LaTex','rotation',90);

set(gcf,'color','w')
